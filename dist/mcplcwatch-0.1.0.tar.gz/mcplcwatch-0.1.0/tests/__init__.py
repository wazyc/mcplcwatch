"""
mcplcwatch テストパッケージ

このパッケージには、mcplcwatchライブラリのテストコードが含まれています。
""" 